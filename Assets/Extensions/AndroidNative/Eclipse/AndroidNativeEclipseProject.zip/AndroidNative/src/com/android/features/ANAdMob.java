package com.android.features;

import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.AdView;

import android.app.Activity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class ANAdMob {
	
	private static LinearLayout layout = null;
	private static AdView adView = null;
	private static Activity mainActivity = null;
	
	private static boolean IsInited = false;
	
	public static void StartAd(int gravity, Activity activity, String id) {
		
		if(IsInited) {
			return;
		}
		
		 IsInited = true;
		 mainActivity = activity;
		
		 adView = new AdView(mainActivity, AdSize.BANNER, id);
		
		 layout = new LinearLayout(mainActivity);
		 layout.setGravity(gravity);
		 
		 
		 layout.addView(adView, new RelativeLayout.LayoutParams(-2, -2));
		 adView.loadAd(new AdRequest());
		 
		 ShowAd();
	}
	
	
	public static void HideAd() {
		if(!IsInited) {
			return;
		}
		
		ViewGroup vg = (ViewGroup)(layout.getParent());
		vg.removeView(layout);
	}
	
	public static void ShowAd() {
		if(!IsInited) {
			return;
		}
		
		mainActivity.addContentView(layout, new RelativeLayout.LayoutParams(-1, -1));
	}
	
	public static void Refresh() {
		 adView.loadAd(new AdRequest());
	}

}
