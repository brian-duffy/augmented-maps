package com.android.billing.core;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.android.billing.interfaces.OnBillingPurchaseFinishedListener;
import com.android.billing.interfaces.OnBillingSetupFinishedListener;
import com.android.billing.interfaces.OnConsumeFinishedListener;
import com.android.billing.interfaces.QueryInventoryFinishedListener;
import com.android.billing.models.BillingResult;
import com.android.billing.models.Inventory;
import com.android.billing.models.Purchase;
import com.android.billing.models.SkuDetails;
import com.unity3d.player.UnityPlayer;


public class BillingManager {
	
	
	public static final int PURCHASE_REQUEST = 10001;

	private final String UNITY_LISTNER_NAME = "AndroidInAppPurchaseManager";
	private final String UNITY_SPLITTER = "|";
	private Activity mContext;

	private Inventory inventory = null;

	public BillingHelper mHelper;
	public ArrayList<String> productList = null;



	public BillingManager(Activity cont) {
		mContext = cont;

	}
	
	

	public void  connect(ArrayList<String> products, String base64EncodedPublicKey) {
		try {
			productList = products;

			Log.d("BillingManager","key: " +  base64EncodedPublicKey);
			mHelper = new BillingHelper(mContext, base64EncodedPublicKey);
			mHelper.enableDebugLogging(true);

			mHelper.startSetup(new OnBillingSetupFinishedListener() {
				public void onSetupFinished(BillingResult result) {
					
					StringBuilder callback =  new StringBuilder();
					callback.append(Integer.toString(result.getResponse()));
					callback.append(UNITY_SPLITTER);
					callback.append(result.getMessage());
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnBillingSetupFinishedCallback", callback.toString());

				}
			});   

		} catch(Exception ex) {
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnBillingSetupFinishedCallback", callback.toString());
			
			Log.d("BillingManager", ex.getMessage());
		}

	}

	public void retrieveProducDetails() {
		try {
			QueryInventoryFinishedListener  mQueryFinishedListener =  new QueryInventoryFinishedListener() {

				@Override
				public void onQueryInventoryFinished(BillingResult result, Inventory inv) {
					if (result.isSuccess()) {

						inventory = inv;
						
						 StringBuilder ownedInfo = new StringBuilder();
						 List<Purchase> purchases  = inventory.getAllPurchases();
						 
						 boolean first = true;
						 for(Purchase p : purchases) {
							 if(!first) {
								 ownedInfo.append(UNITY_SPLITTER);
							 }
							 ownedInfo.append(p.getSku());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getPackageName());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getDeveloperPayload());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getOrderId());
							 first = false;
						 }
						 
						 UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPurchasesRecive", ownedInfo.toString());
						
						 first = true;
						 StringBuilder productsInfo = new StringBuilder();
						 List<SkuDetails> products  = inventory.getAllProducts();
						 for(SkuDetails p : products) {
							 if(!first) {
								 productsInfo.append(UNITY_SPLITTER);
							 }
							 productsInfo.append(p.getSku());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getPrice());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getTitle());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getDescription());
							 first = false;
						 }
						 
						 UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnProducttDetailsRecive", productsInfo.toString());
					

					}
					
					StringBuilder callback =  new StringBuilder();
					callback.append(Integer.toString(result.getResponse()));
					callback.append(UNITY_SPLITTER);
					callback.append(result.getMessage());
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnQueryInventoryFinishedCallBack", callback.toString());

				}
			};

			mHelper.queryInventoryAsync(true, productList, mQueryFinishedListener);  
		} catch(Exception ex) {
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnQueryInventoryFinishedCallBack", callback.toString());
			
			Log.d("BillingManager", ex.getMessage());
		}
		
	}
	
	
	public void consume(String SKU) {
		try {
			OnConsumeFinishedListener mConsumeFinishListner = new OnConsumeFinishedListener() {
				
				@Override
				public void onConsumeFinished(Purchase purchase, BillingResult result) {
					StringBuilder callback =  new StringBuilder();
					callback.append(Integer.toString(result.getResponse()));
					callback.append(UNITY_SPLITTER);
					callback.append(result.getMessage());
					
					

					if (result.isSuccess()) {

						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getSku());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getPackageName());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getDeveloperPayload());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getOrderId());
						
						if(inventory != null) {
							inventory.erasePurchase(purchase.getSku());
						} 
						
				    }
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnConsumeFinishedCallBack", callback.toString());
					
				}
			};
			
			mHelper.consumeAsync(inventory.getPurchase(SKU), mConsumeFinishListner);
		} catch(Exception ex) {
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnConsumeFinishedCallBack", callback.toString());
			
			//Log.d("BillingManager", ex.getMessage());
		}
		
	}
	
	public void purchase(String SKU, String developerPayload) {
		
		try {
			OnBillingPurchaseFinishedListener mPurchaseFinishedListener = new OnBillingPurchaseFinishedListener() {
				
				@Override
				public void onPurchaseFinished(BillingResult result, Purchase purchase) {
					
					StringBuilder callback =  new StringBuilder();
					callback.append(Integer.toString(result.getResponse()));
					callback.append(UNITY_SPLITTER);
					callback.append(result.getMessage());
					
					

					if (result.isSuccess()) {
	
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getSku());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getPackageName());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getDeveloperPayload());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getOrderId());
						
						if(inventory != null) {
							inventory.addPurchase(purchase);
						} 
				    }
					
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPurchaseFinishedCallback", callback.toString());
					
				}
			};
			
			mHelper.launchPurchaseFlow(mContext, SKU, PURCHASE_REQUEST,  mPurchaseFinishedListener, developerPayload);
		} catch(Exception ex) {
			
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPurchaseFinishedCallback", callback.toString());
			
			Log.d("BillingManager", ex.getMessage());
		}
		
	}
	
	
	public void handleActivityResult(int requestCode, int resultCode, Intent data)  {
		mHelper.handleActivityResult(requestCode, resultCode, data);
	}



	public void dispose() {
		if(mHelper != null) {
			mHelper.dispose();
		}
		
		mHelper = null;
	}
	
	
}
