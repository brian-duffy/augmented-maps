package com.android;

import java.util.ArrayList;
import java.util.Calendar;

import com.android.billing.core.BillingManager;
import com.android.features.ANAdMob;
import com.android.features.AlarmReceiver;
import com.android.gs.GameClientManager;
import com.android.popups.PopUpsManager;
import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.AdView;
import com.unity3d.player.UnityPlayerActivity;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
//import android.app.TaskStackBuilder;
import android.support.v4.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class AndroidNativeBridge extends UnityPlayerActivity {

	private static AndroidNativeBridge inst = null;
	private static BillingManager billing = null;
	private static GameClientManager playService;

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		inst = this;
		playService = new GameClientManager();

	}

	public static AndroidNativeBridge GetInstance() {
		return inst;
	}

	// --------------------------------------
	// Google Cloud
	// --------------------------------------

	public void listStates() {
		playService.listStates();
	}

	public void updateState(String stateKey, String data) {
		playService.updateState(Integer.parseInt(stateKey), data);
	}

	public void deleteState(String stateKey) {
		playService.deleteState(Integer.parseInt(stateKey));
	}

	public void loadState(String stateKey) {
		playService.loadState(Integer.parseInt(stateKey));
	}

	public void resolveState(String stateKey, String resolvedData,
			String resolvedVersion) {
		playService.resolveState(Integer.parseInt(stateKey), resolvedData,
				resolvedVersion);
	}

	// --------------------------------------
	// Google Play Services
	// --------------------------------------

	public void startPlayService(String clientsToUse) {
		playService.startPlayService(this, clientsToUse);
	}

	public void playServiceConnect() {
		playService.beginUserInitiatedSignIn();
	}

	public void playServiceDisconnect() {
		playService.signOut();
	}

	public void showAchivments() {
		playService.showAchivmentsUI();
	}

	public void showLeaderBoards() {
		playService.showLeaderBoardsUI();
	}

	public void showLeaderBoard(String leaderboardName) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		showLeaderBoardById(leaderboardId);
	}

	public void showLeaderBoardById(String leaderboardId) {
		playService.showLeaderBoardUI(leaderboardId);
	}

	public void loadPlayer() {
		playService.LoadPlayer();
	}

	public void submitScore(String leaderboardName, String score) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		submitScoreById(leaderboardId, score);
	}

	public void submitScoreById(String leaderboardId, String score) {
		playService.submitScore(leaderboardId, Integer.parseInt(score));
	}

	public void loadLeaderBoards() {
		playService.loadLeaderBoards();
	}

	public void reportAchievement(String achievementName) {
		String achievementId = getStringResourceByName(achievementName);
		reportAchievementById(achievementId);
	}

	public void reportAchievementById(String achievementId) {
		playService.reportAchievement(achievementId);
	}

	public void revealAchievement(String achievementName) {
		String achievementId = getStringResourceByName(achievementName);
		revealAchievementById(achievementId);
	}

	public void revealAchievementById(String achievementId) {
		playService.revealAchievement(achievementId);
	}

	public void incrementAchievement(String achievementName, String numsteps) {
		String achievementId = getStringResourceByName(achievementName);
		incrementAchievementById(achievementId, numsteps);
	}

	public void incrementAchievementById(String achievementId, String numsteps) {
		playService.incrementAchievement(achievementId,
				Integer.parseInt(numsteps));
	}

	public void loadAchivments() {
		playService.loadAchivments();
	}

	// --------------------------------------
	// BILLING
	// --------------------------------------

	public void connectToBilling(String ids, String base64EncodedPublicKey) {
		billing = new BillingManager(this);

		ArrayList<String> products = new ArrayList<String>();
		String[] result = ids.split(",");

		for (String id : result) {
			products.add(id);
		}

		billing.connect(products, base64EncodedPublicKey);
	}

	public void retrieveProducDetails() {
		billing.retrieveProducDetails();
	}

	public void consume(String SKU) {
		billing.consume(SKU);
	}

	public void purchase(String SKU, String developerPayload) {
		billing.purchase(SKU, developerPayload);
	}

	// --------------------------------------
	// MESSAGING
	// --------------------------------------

	public void ShowMessage(String title, String message, String ok) {
		PopUpsManager.ShowMessage(title, message, ok);
	}

	public void showDialog(String title, String message, String yes, String no) {
		PopUpsManager.ShowDialog(title, message, yes, no);
	}

	public void ShowRateDialog(String title, String message, String yes,
			String laiter, String no, String url) {
		PopUpsManager.ShowRateDialog(title, message, yes, laiter, no, url);
	}

	// --------------------------------------
	// OTHER FEATURES
	// --------------------------------------

	public void StartAdMob(String id, String gravity) {
		ANAdMob.StartAd(Integer.parseInt(gravity), this, id);
	}

	public void HideAd() {
		ANAdMob.HideAd();
	}

	public void ShowAd() {
		ANAdMob.ShowAd();
	}

	public void RefreshAd() {
		ANAdMob.Refresh();
	}

	public void ShowToastNotification(String text, String duration) {
		Context context = getApplicationContext();

		Toast toast = Toast.makeText(context, text, Integer.parseInt(duration));
		toast.show();
	}

	public void scheduleNotification() {
		Log.d("Custom", "scheduleNotification onStart: ");
		// get a Calendar object with current time
		Calendar cal = Calendar.getInstance();
		// add 5 minutes to the calendar object
		cal.add(Calendar.SECOND, 10);
		Intent intent = new Intent(getBaseContext(), AlarmReceiver.class);
		intent.putExtra("alarm_message", "O'Doyle Rules!");

		// In reality, you would want to have a static variable for the request
		// code instead of 192837
		PendingIntent sender = PendingIntent.getBroadcast(this, 192837, intent,
				PendingIntent.FLAG_UPDATE_CURRENT);

		// Get the AlarmManager service
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), sender);
	}
	
	public void notifyUser(){
		 
		Log.d("Custom", "notifyUser onStart: ");
		
		NotificationCompat.Builder mBuilder =
		        new NotificationCompat.Builder(this)
		        .setContentTitle("My notification")
		        .setContentText("Hello World!");
		// Creates an explicit intent for an Activity in your app
		Intent resultIntent = new Intent(this, AlarmReceiver.class);

		// The stack builder object will contain an artificial back stack for the
		// started Activity.
		// This ensures that navigating backward from the Activity leads out of
		// your application to the Home screen.
		TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
		// Adds the back stack for the Intent (but not the Intent itself)
		stackBuilder.addParentStack(AlarmReceiver.class);
		// Adds the Intent that starts the Activity to the top of the stack
		stackBuilder.addNextIntent(resultIntent);
		PendingIntent resultPendingIntent =
		        stackBuilder.getPendingIntent(
		            100500,
		            PendingIntent.FLAG_UPDATE_CURRENT
		        );
		mBuilder.setContentIntent(resultPendingIntent);
		NotificationManager mNotificationManager =
		    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		// mId allows you to update the notification later on.
		mNotificationManager.notify(100500, mBuilder.build());
	 
	}
	
	public Drawable getFullResDefaultActivityIcon() {
	    return getFullResIcon(Resources.getSystem(), android.R.mipmap.sym_def_app_icon);
	}

	public Drawable getFullResIcon(Resources resources, int iconId) {
	    Drawable d;
	    try {
	        ActivityManager activityManager = (ActivityManager) getBaseContext().getSystemService(Context.ACTIVITY_SERVICE);
	        int iconDpi = activityManager.getLauncherLargeIconDensity();
	        d = resources.getDrawableForDensity(iconId, iconDpi);
	    } catch (Resources.NotFoundException e) {
	        d = null;
	    }

	    return (d != null) ? d : getFullResDefaultActivityIcon();
	}

	// --------------------------------------
	// Override
	// --------------------------------------

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (billing != null) {
			billing.handleActivityResult(requestCode, resultCode, data);
		}

		if (GameClientManager.isStarted()) {
			playService.onActivityResult(requestCode, resultCode, data);
		}

	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		if (billing != null) {
			billing.dispose();
		}
		billing = null;
	}

	@Override
	protected void onStart() {
		super.onStart();
		if (GameClientManager.isStarted()) {
			Log.d("Custom", "playService onStart: ");
			playService.onStart(this);
		}

	}

	@Override
	protected void onStop() {
		super.onStop();

		if (GameClientManager.isStarted()) {
			playService.onStop();
		}

	}

	// --------------------------------------
	// Private Methods
	// --------------------------------------

	private String getStringResourceByName(String aString) {
		String packageName = getPackageName();
		int resId = getResources()
				.getIdentifier(aString, "string", packageName);
		return getString(resId);
	}

}
